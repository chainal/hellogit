package main

import "fmt"
import "net/http"

func main() {
	fmt.Println("Hello world!")
	http.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
		fmt.Fprintf(w, "Hello world, liuchuang")
	:i})
	error := http.ListenAndServeTLS(":443", "1_lccte.club_bundle.crt", "2_lccte.club.key", nil)
	if error != nil {
		fmt.Println("error on start http.ListenAndServeTLS")
	}
}
